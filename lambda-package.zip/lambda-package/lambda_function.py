import boto3
import requests

def lambda_handler(event, context):
    # Spotify API credentials
    CLIENT_ID = 'b11178fe5f354b12a98234fa4bbe95e5'
    CLIENT_SECRET = '3c71248dd25949a3b1f844bb2ebb713b'
    SPOTIFY_API_URL = 'https://api.spotify.com/v1/artists/1Xyo4u8uXC1ZmMpatF05PJ'  # Example API endpoint
    
    # Fetch token
    auth_response = requests.post(
        'https://accounts.spotify.com/api/token',
        data={'grant_type': 'client_credentials'},
        headers={'Authorization': f'Basic {base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()}'}
    )
    access_token = auth_response.json()['access_token']
    
    # Fetch data from Spotify API
    response = requests.get(SPOTIFY_API_URL, headers={'Authorization': f'Bearer {access_token}'})
    data = response.json()
    
    # Save to S3
    s3 = boto3.client('s3')
    s3.put_object(
        Bucket='spotify-raw-data-abd',  # Your S3 bucket name
        Key='raw_data.json',
        Body=json.dumps(data)
    )
    return {'statusCode': 200, 'body': 'Data successfully saved to S3'}
